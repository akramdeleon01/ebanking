package emsi.projet.ebankingbackend.enums;

public enum OperationType {
    DEBIT , CREDIT
}
